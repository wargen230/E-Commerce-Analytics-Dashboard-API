namespace E_Commerce_Analytics_Dashboard_API.Tests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}